#Plot and Navigate a Virtual Maze

